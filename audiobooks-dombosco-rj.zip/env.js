// Deixe vazio ou sobrescreva campos sem editar o JSON:
// window.APP_ENV = {
//   audio: { src: 'assets/audio/Fund1-Sem-Artes.mp3', download: 'assets/audio/Fund1-Sem-Artes.mp3', title: 'Sem Artes' },
//   ui: { pageTitle: 'Fund 1 - Sem Artes', trackTitle: 'Sem Artes' },
//   links: { cta: 'https://domboscorj.com.br/contato' }
// };
